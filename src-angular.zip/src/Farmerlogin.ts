export class Farmerlogin{

    farmerEmail: string;
    password: string;

}