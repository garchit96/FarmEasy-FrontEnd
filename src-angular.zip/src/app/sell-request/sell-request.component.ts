import { Component, OnInit } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { CropDetail } from 'src/CropDetail';
import { FarmEasyService } from '../farm-easy.service';

@Component({
  selector: 'app-sell-request',
  templateUrl: './sell-request.component.html',
  styleUrls: ['./sell-request.component.css']
})
export class SellRequestComponent implements OnInit {
 

  constructor(private farmEasyService: FarmEasyService) { }

  ngOnInit(): void {
  }

  onSubmit(f: NgForm)
  {
     console.log(f.value) ;
      // this.farmEasyService.mail(this.email).subscribe();
       f.value.farmerDetail.farmerEmail=sessionStorage.getItem('femail');
       f.value.sellReqStatus="Pending";
      this.farmEasyService.addNewSellRequest(f.value).subscribe(data => console.log(data));
    }
  }
