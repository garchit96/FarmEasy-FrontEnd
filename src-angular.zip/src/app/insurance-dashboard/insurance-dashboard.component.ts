import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-insurance-dashboard',
  templateUrl: './insurance-dashboard.component.html',
  styleUrls: ['./insurance-dashboard.component.css']
})
export class InsuranceDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
