import { FarmerDetail } from "./FarmerDetail";

export class FarmerLandDetail{
    landAddress: string;
    landArea: number;
    landPincode: number; 
    farmerDetail: FarmerDetail;
    }