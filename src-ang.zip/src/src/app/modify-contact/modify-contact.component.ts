import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modify-contact',
  templateUrl: './modify-contact.component.html',
  styleUrls: ['./modify-contact.component.css']
})
export class ModifyContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
