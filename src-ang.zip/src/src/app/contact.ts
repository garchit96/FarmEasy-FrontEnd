export class Contact
{
    firstname: string;
    lastname: string;
    phone: string;
}