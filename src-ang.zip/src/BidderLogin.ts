export class BidderLogin{

    bidderEmail: string;
    password: string;
}