export class ViewSoldHistory{

    cropName: string;
    quantityKg: number;
    msp: number;
    soldPrice: number;
    totalPrice: number;
    sellReqDate: Date;
}